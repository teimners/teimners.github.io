# frozen_string_literal: true

module Minima
  VERSION = "2.5.2"
end
